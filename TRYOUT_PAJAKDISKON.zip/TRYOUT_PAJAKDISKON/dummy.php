<?php

$furniture = [
    [
        "id"        =>0,
        "name"      =>"sofa",
        "deskripsi" =>"sudah termasuk dengan sofa dan meja",
        "price"     =>3000000,
        "image"     =>"sofa.jpg",
    ],
    [
        "id"        =>1,
        "name"      =>"lemari",
        "deskripsi" =>"lemari dengan fitur keamanan jangkar dan buka kunci",
        "price"     =>2500000,
        "image"     =>"lemari.jpg",
    ],
    [
        "id"        =>2,
        "name"      =>"kasur",
        "deskripsi" =>"sudah termasuk dengan bantal dan guling",
        "price"     =>4500000,
        "image"     =>"kasur.jpg",
    ],
    [
        "id"        =>3,
        "name"      =>"lampu hias",
        "deskripsi" =>"sudah termasuk dengan pasang",
        "price"     =>3500000,
        "image"     =>"lampu.jpg",
    ],
];
?>
