<?php
//fungsi require untuk memasukkan file data.php agar isi dari data.php dapat digunakan dalam file index.php
//selain require juga ada include dengan fungsi yang sama dengan require
require 'dummy.php';

?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Furniture</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  </head>
  <body>
    <div class="container mt-5">
        <!--Navbar-->
        <nav class="navbar navbar-expand-lg bg-body border-bottom sticky-top ">
    <div class="container">
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
        <div class="navbar-nav ms-auto">
          <a class="nav-link active text-info" href="#">Home</a>
          <a class="nav-link text-info" href="#">Pembayaran</a>
          <a class="nav-link text- info" href="login.php">Logout</a>
        </div>
      </div>
    </div>
  </nav>
  <!-- End Navbar-->

  <!-- Banner -->
  <section class="banner" id="home">
    <div class="container">
      <div class="row">
        <div class="text-center">
          <img src="logo.jpg" alt="banner" class="">
        </div>
      </div>
    </div>

  </section>
  
        <h1 class="text-center"> PEMILIHAN FURNITURE</h1>
        
        <div class="row gx-5">
            <?php
            //fungsi perulangan foreach digunakan untuk menampilkan data array.
            //variabel $book didapat dari file data.php
            //variabel $index untuk mendapatkan index dari array multidimensi
            //variabel $value untuk mendapatkan isi dari array asosiatif
            
            foreach($furniture as $index => $value): ?>
            <div class="col-3 mb-5 ">
                 <div class="card h-100" style="width: 18rem;">
                     <img src="<?= $value['image'] ?>" class="card-img-top" alt="...">
                     <div class="card-body">
                    <h5 class="card-title"><?= $value['name']?></h5>
                    <p class="card-text">deskripsi : <?= $value['deskripsi']?></p>
                    <p class="card-text">Harga : <?=number_format($value['price'])?></p>
                      <a href="pembayaran.php?id=<?= $index?>" class="btn btn-primary">Pilih</a>
                      </div>
                  </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  </body>
</html>