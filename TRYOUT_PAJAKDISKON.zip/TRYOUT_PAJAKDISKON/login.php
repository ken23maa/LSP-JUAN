<!DOCTYPE html>
<html>
<head>
	<title>Login - Furniture</title>
	<link rel="stylesheet" type="text/css" href="style.css">
  <link href="bootstrap-icons.css" rel="stylesheet">
</head>
<body>
    <div class="wrapper">
<div class="form-box login">
                <h2>Login </h2>
                
                    <p>Login untuk mengakses data</p>
                <form action="index.php" method="post">
                    <div class="input-box">
                        <span class="icon"><i class="bi bi-person-fill"></i></span>
                        <input type="text" name="username">
                        <label>Username</label>
                    </div>
                    <div class="input-box">
                        <span class="icon"><i class="bi bi-lock-fill"></i></span>
                        <input type="password" name="password">
                        <label>Password</label>
                    </div>
                    <button type="submit" class="btn" name="login">Login</button>
                </form>
            </div>
    </div>
</body>

<?php
   session_start(); //untuk menyimpan data pengguna yang telah login

             if(isset($_POST["Login"])){
               if($_POST["username"] == "userlsp" && $_POST["password"]  == "juan"){
                   // simpan data pengguna ke dalam session
                   $_SESSION['username'] = $_POST['username'];
                 //memindahkan ke halaman home
                 header("Location: index.php");
             } else { //jika username atau password salah
               echo"
                   <script>
                   alert('user atau password salah')                   
                   </script>";
             }
           }

?>
</html>