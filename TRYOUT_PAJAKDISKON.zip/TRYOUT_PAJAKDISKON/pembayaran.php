<?php
require 'dummy.php';
$id = $_GET['id'];

session_start();
if(!isset($_SESSION['username'])){
    header('Location : login.php');
}

$username = $_SESSION['username'];
?>

<!doctype html>
<html lang="en">

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Furniture</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    </head>
    <body>

            <nav class="navbar navbar-expand-lg bg-body border-bottom sticky-top">
            <div class="container">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                <div class="navbar-nav ms-auto">
                <a class="nav-link active" href="#">Home</a>
                <a class="nav-link" href="#">Pembayaran</a>
                <a class="nav-link" href="login.php">Logout</a>
                </div>
            </div>
            </div>
        </nav>

        <div class="container">
            <h1>Pembayaran Furniture</h1>

            <form action="">
                <div class="mb-3">
                    <label for="title" class="form-label">No Transaksi :</label>
                    <input type="text" id="transaksi" class="form-control" value="">
                </div>

                <div class="mb-3">
                    <label for="no-transaksi" class="form-label">Tanggal Transaksi :</label>
                    <input type="date" id="tanggal" class="form-control" value="" >
                </div>

                <div class="mb-3">
                    <label for="nama-pembeli" class="form-label">Nama Pembeli :</label>
                    <input type="text" id="nama" class="form-control" value="">
                </div>

                <div class="mb-3">
                    <label for="jus" class="form-label">Pilihan Furniture :</label>
                    <input type="text" id="jus" class="form-control" value="<?= $furniture[$id]['name'] ?>" readonly>
                </div>

                <div class="mb-3">
                    <label for="price" class="form-label">Harga Furniture :</label>
                    <input type="text" id="price" class="form-control" value="<?= $furniture[$id]['price'] ?>" readonly>
                </div>


                <div class="mb-3">
                    <label for="jumlah" class="form-label">Jumlah Dibeli : </label>
                    <input type="number" id="jumlah" class="form-control">
                </div>

                <div class="mb-3">
                    <label for="jus" class="form-label">Harga pajak :</label>
                    <input type="text" id="Pajak" class="form-control" readonly>
                </div>

                <div class="mb-3">
                    <label for="jus" class="form-label">harga diskon :</label>
                    <input type="text" id="Diskon" class="form-control" readonly>
                </div>

                <button type="button" onclick="hitungtotal()" class="btn btn-primary">Hitung Total</button>
                
                <div class="mb-3">
                    <label for="total" class="form-label">Total Pembayaran: </label>
                    <input type="number" id="totalHarga" name="totalHarga" class="form-control">
                </div>

                <div class="mb-3">
                    <label for="pembayaran" class="form-label">Pembayaran : </label>
                    <input type="number" id="pembayaran" class="form-control">
                </div>

                <button type="button" onclick="hitungKembalian()" class="btn btn-primary">Hitung Kembalian</button>

                <div class="mb-3">
                    <label for="total" class="form-label">Kembalian : </label>
                    <input type="number" id="kembalian" class="form-control">
                </div>
                <button type="button" onclick="window.location.href='index.php'" class="btn btn-primary">Simpan Transaksi</button>

            </form>

        
        </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

    <script>
        function hitungtotal() {
            let price = parseInt(document.getElementById("price").value);
            let jumlah = parseInt(document.getElementById("jumlah").value);
            let  totalHarga = price * jumlah;
            let diskon = 0;
            if(totalHarga > 5000000) {
                diskon = 0.5; // diskon 50%
            }else if (totalHarga > 3000000 ) {
                diskon =  0.1; // diskon 10%
            }

            // hitung total harga setelah diskon
            let totalHargaSetelahDiskon = totalHarga * (1 - diskon );

            //hitung pajak
            let pajak = 0.05; //pajak 5%

            // hitung total harga setelah pajak dan diskon
            let totalHargaSetelahPajak = totalHargaSetelahDiskon + totalHarga * pajak;

            document.getElementById("totalHarga").value = totalHargaSetelahPajak;
            document.getElementById("Diskon").value = (diskon * totalHarga);
            document.getElementById("Pajak").value = (pajak * totalHarga) ;
         
        }
        

        function hitungKembalian(){
            let price = parseInt(document.getElementById("totalHarga").value);
            let pembayaran = parseInt(document.getElementById("pembayaran").value);

                let kembalian = pembayaran - price;
                document.getElementById("kembalian").value = kembalian;
        
    }   
    
    const proses = document.getElementById('proses');
proses.addEventListener('click', function() {
    window.location = "index.php";
});
    </script>

    </body>
</html>