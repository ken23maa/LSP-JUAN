<?php
    if(isset($_POST["login"])){
        if($_POST["username"]=="userlsp" && $_POST["password"]=="juan"){
            session_start();
            $_SESSION['username']= $_POST['username'];
            header("location: index.php");
        }
        else{
            echo"
            <script>
            alert('username atau password yang anda masukkan salah')
            </script>
            ";
        }
    }
    ?>