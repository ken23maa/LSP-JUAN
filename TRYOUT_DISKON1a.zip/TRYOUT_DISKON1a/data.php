<?php
$Jus = [
    [
        'id' => 0,
        'name' => 'Jus Buah Manggo ',
        'description' => 'Manggo Susu',
        'price' => 15000,
        'gambar' => 'mango.jpg',
    ],

    [
        'id' => 1,
        'name' => 'Jus Buah Jeruk Peras',
        'description' => 'Jeruk Pilihan Terbaik',
        'price' => 17000,
        'gambar' => 'es-jeruk-peras.jpg',
    ],

    [
        'id' => 2,
        'name' => 'Jus Buah Naga',
        'description' => 'Buah Naga Yang Terbaik',
        'price' => 10000,
        'gambar' => 'buahnaga.jpeg',
    ],

    [
        'id' => 3,
        'name' => 'Jus Apel Sick',
        'description' => 'Apel Pilihan Kebun Sendiri',
        'price' => 15000,
        'gambar' => 'apel.avif',
    ],

    ];