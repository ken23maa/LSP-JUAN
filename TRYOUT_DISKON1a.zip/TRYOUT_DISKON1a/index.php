<?php  require 'data.php';

session_start();
if(!isset($_SESSION['username'])){
    header('Location : login.php');
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <title>Jual Beli Musang</title>
  <link rel="stylesheet" href="assets/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
  <!-- Navbar -->
  <nav class="navbar navbar-expand-lg bg-body border-bottom sticky-top">
    <div class="container">
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
        <div class="navbar-nav ms-auto">
          <a class="nav-link active" href="#">Home</a>
          <a class="nav-link" href="#">Pembayaran</a>
          <a class="nav-link" href="login.php">Logout</a>
        </div>
      </div>
    </div>
  </nav>
  <!-- End Navbar -->


  <div id="carouselExample" class="carousel slide">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="images/bannerhome.webp" class="d-block w-100" alt="...">
    </div>
</div>


  <!-- Content -->
  <section class="content" id="content">
    <div class="container">
      <h3 class="mb-4">Jus Buah Terbaik</h3>

      <div class="list_room">
        <div class="row">

        <?php foreach ($Jus as $item) :?>
          <div class="col-lg-3 mb-1">
            <img src="images/<?= $item['gambar']?>" alt="standard" class="img-fluid mb-2" style: width :100px;>
            <h5><?= $item['name']?></h5>
            <h6><?= $item['description']?></h6>
            <p>Rp.<?=number_format($item['price'])?></p>
            <a href="transaksi.php?id=<?=$item['id']?>" class="btn btn-primary-custom-sm shadow">Beli Sekarang</a>
          </div>
          <?php  endforeach; ?>

          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- End Content -->

  <!-- Footer -->
  <footer class="footer">
      <p class="mt-3 mb-3 text-center">2024 Copyright by Hendra Jayasa. All rights reserved. </p>
    </div>
  </footer>
  <!-- End Footer -->

  <script src="assets/js/bootstrap.bundle.min.js"></script>
</body>
</html>