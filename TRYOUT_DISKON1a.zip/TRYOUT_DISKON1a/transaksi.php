<?php
require 'data.php';
$id = $_GET['id'];

session_start();
if(!isset($_SESSION['username'])){
    header('Location : login.php');
}

$username = $_SESSION['username'];
?>

<!doctype html>
<html lang="en">

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    </head>
    <body>
        <div class="container">
            <h1>Pemesanan Jus Buah</h1>

            <form action="">
                <div class="mb-3">
                    <label for="title" class="form-label">No Transaksi :</label>
                    <input type="text" id="transaksi" class="form-control" value="" readonly>
                </div>

                <div class="mb-3">
                    <label for="no-transaksi" class="form-label">Tanggal Transaksi :</label>
                    <input type="date" id="tanggal" class="form-control" value="" readonly>
                </div>

                <div class="mb-3">
                    <label for="nama-pembeli" class="form-label">Nama Pembeli :</label>
                    <input type="text" id="nama" class="form-control" value="<?=$username ?>"readonly>
                </div>

                <div class="mb-3">
                    <label for="jus" class="form-label">Pilihan Handphone :</label>
                    <input type="text" id="jus" class="form-control" value="<?= $Jus[$id]['name'] ?>" readonly>
                </div>

                <div class="mb-3">
                    <label for="price" class="form-label">Harga :</label>
                    <input type="text" id="price" class="form-control" value="<?= $Jus[$id]['price'] ?>" readonly>
                </div>

                <div class="mb-3">
                    <label for="jumlah" class="form-label">Jumlah Dibeli : </label>
                    <input type="number" id="jumlah" class="form-control">
                </div>

                <div class="mb-3">
    <label for="diskon" class="form-label">Diskon (%) :</label>
    <input type="number" id="diskon" class="form-control" min="0" max="100" step="1" value="0">
</div>

                <button type="button" onclick="hitungtotal()" class="btn btn-primary">Hitung Total</button>

                <div class="mb-3">
                    <label for="total" class="form-label">Total Bayar : </label>
                    <input type="number" id="totalHarga" name="totalHarga" class="form-control">
                </div>



                
                <div class="mb-3">
                    <label for="pembayaran" class="form-label">Pembayaran : </label>
                    <input type="number" id="pembayaran" class="form-control">
                </div>

                <button type="button" onclick="hitungKembalian()" class="btn btn-primary">Hitung Kembalian</button>

                <div class="mb-3">
                    <label for="total" class="form-label">Kembalian : </label>
                    <input type="number" id="kembalian" class="form-control">
                </div>
                <button type="button" onclick="simpan" class="btn btn-primary">Simpan Transaksi</button>
                
            </form>

        
        </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

    <script>
function hitungtotal() {
    let price = parseInt(document.getElementById("price").value);
    let jumlah = parseInt(document.getElementById("jumlah").value);
    let diskon = parseInt(document.getElementById("diskon").value);
    
    let totalHarga = price * jumlah;
    let potonganDiskon = (totalHarga * diskon) / 100;
    totalHarga -= potonganDiskon;
    
    document.getElementById("totalHarga").value = totalHarga;
}


        function hitungKembalian(){
            let price = parseInt(document.getElementById("totalHarga").value);
            let pembayaran = parseInt(document.getElementById("pembayaran").value);

            if(pembayaran >= price){
            let kembalian = pembayaran - price;
            document.getElementById("kembalian").value = kembalian;
        }else{
            alert("Uang Anda Tidak Cukup");
        }
    }

    
    const proses = document.getElementById('proses');

proses.addEventListener('click', function() {
if (pembayaran.value === "" && kembalian  .value === "") {
    alert('Jumlah atau total bayar harus diisi');
} else {
    window.location = "index.php";
}
});
    </script>

    </body>
</html>