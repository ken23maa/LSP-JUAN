<?php
$kereta = [
    [
        "id"      => 0,
        "name"    => "Damri",
        "rute"    => "Banjarmasin-Batulicin-Balikpapan",
        "price"   => 450000,
        "image"   => "damri.jpg",
    ],
    [
        "id"      => 1,
        "name"    => "PO Yessoe Travel",
        "rute"    => "Banjarmasin-Palangkaraya",
        "price"   => 150000,
        "image"   => "yossoe.jpg",
    ],
    [   
        "id"      => 2,
        "name"    => "PO Logos Travel",
        "rute"    => "Banjarmasin-Sampit",
        "price"   => 270000,
        "image"   => "logos.jpg",
    ],
    [
        "id"      => 3,
        "name"    => "PO Agung Mulia Travel",
        "rute"    => "Palangkaraya-pangkalanbun",
        "price"   => 350000,
        "image"   => "agung.jpg",
    ],
];