<!DOCTYPE html>
<html>
<head>
	<title>KERETA BAKULA</title>
	<link rel="stylesheet" type="text/css" href="login.css">
  <link href="bootstrap-icons.css" rel="stylesheet">
</head>
<body>

<div id="container">
        <div class="form-box">
            <div class="ic-account"></div>
            <form id="login-form" name="login-form" action="" method="post">
                <label for="username"> Username :</label>
                <input  class="login-form-input" type="text" name="username" placeholder="Username" required>
                <label for="password"> Password :</label>
                <input  class="login-form-input" type="password" name="password" placeholder="password" required>
                <button type="submit" class="login-form-btn" name="Login" value="Login">Login</button>
            </form>
        </div>
    </div>


    <?php
    session_start(); //untuk menyimpan data pengguna yang telah login

              if(isset($_POST["Login"])){
                if($_POST["username"] == "userlsp" && $_POST["password"]  == "juan"){
                    // simpan data pengguna ke dalam session
                    $_SESSION['username'] = $_POST['username'];
                  //memindahkan ke halaman home
                  header("Location: index.php");
              } else { //jika username atau password salah
                echo"
                    <script>
                    alert('user atau password salah')                   
                    </script>";
              }
            }

              ?>
            
</body>
</html>
