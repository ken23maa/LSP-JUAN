<?php require 'data.php';
$id = $_GET['id'];
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
  <title>Checkout</title>
  <link rel="stylesheet" href="assets/css/bootstrap.min.css">
</head>
<body>
  <!-- Navbar -->
  <nav class="navbar navbar-expand-lg m-3" style="border-radius:5px; background-color: #387ADF;">
            <div class="container-fluid">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li><a class="nav-link active text-light" aria-current="page" href="index.php">Home</a></li>
                    <li><a class="nav-link active text-light" aria-current="page" href="checkout.php">Checkout</a></li>
                </ul>
                <div class="log">
                  <a href="loginn.php" class="btn btn-outline-dark btn-outline-info-">Log Out</a>
                </div>
              
              </div>
            </div>
          </nav>
  <!-- End Navbar -->

  <!-- Transaksi -->
  <section class="transaksi" id="transaksi">
    <div class="container">
      <h3 class="mb-5">Checkout</h3>

      
        <div class="col-md-6">
          <div class="informasi">
            <div class="row mb-2">
              <div class="col-md-6">
                <h5><?= $data[$id]['nama'] ?></h5>
              </div>
            </div>
          </div>
        </div>
    
          <form>
            <div class="mb-3">
              <label for="name" class="form-label">No Transaksi</label>
              <input type="text" class="form-control" id="name">
            </div>

            <div class="mb-3">
              <label for="date" class="form-label">Tanggal Transaksi</label>
              <input type="date" class="form-control" id="date">
            </div>

            <div class="mb-3">
              <label for="text" class="form-label">Nama Pembeli</label>
              <input type="text" class="form-control" id="text">
            </div>

            <div class="mb-3">
              <label for="tipe" class="form-label">Tipe</label>
              <input type="text" class="form-control" value="<?= $data[$id]['nama'] ?>" id="tipe">
            </div>

            <div class="mb-3">
              <label for="harga" class="form-label">Harga</label>
              <input type="text" class="form-control" value="<?= $data[$id]['harga'] ?>" id="harga" readonly>
            </div>

            <div class="mb-3">
              <label for="jumlah" class="form-label">Jumlah Di Beli</label>
              <input type="text" class="form-control" id="jumlah">
            </div>

            <div class="mb-3">
            <label for="diskon" class="form-label">Diskon (%) :</label>
            <input type="number" id="diskon" class="form-control" min="0" max="100" step="1" value="0">
            <div class="col-md-6">

                <h5 id="subtotal">JUMLAH : Rp.</h5>
            </div>

            <button id="transaksi" type="button" onclick="hitungtotal()" class="btn btn-primary">Total</button>
               
            <input type="hidden" id="harga" value="<?= $data[$id]['harga'] ?>">

          </form>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- End Transaksi -->

<!--Hitung Kembalian -->
<th>
  <form class="m-2 border p-3 row flex-wrap" style="width: 100%;" id="myform" method="post">
  <div class="col-6">
            <label for="nomor-pembayaran" class="form-label">Total Harga</label>
            <input type="text" class="form-control" name="total-harga" id="total-harga" readonly>
        </div>
        
        <div class="col-6">
            <label for="nomor-pembayaran" class="form-label">Total Setelah Diskon</label>
            <input type="text" class="form-control" name="total-setelah-diskon" id="total-setelah-diskon" readonly>
        </div>
        <div class="col-6">
            <label for="nomor-pembayaran" class="form-label">Kembalian</label>
            <input type="text" class="form-control" name="total-harga" id="kembalian-id" readonly required>
        </div>
        <div class="col-6" style="padding-top: 20px;">
            <label for="nomor-pembayaran" class="form-label">Masukkan Uang Anda</label>
            <input type="text" class="form-control" name="total-harga" id="pembayaran-id" required>
        </div>
        <div class="col-6" style="padding-top: 30px;">
            <button type="button" onclick="hitungkembalian()" class="btn btn-primary">hitung kembalian</button>
            <button type="button" class="btn btn-warning color-#387ADF" onclick="window.location.href='home.php'">Simpan</button>
        </div>
    </form>
</th>
  <!--End Hitung Kembalian -->
  
  <script src="assets/js/bootstrap.bundle.min.js"></script>

  <script>
    let jumlah = document.getElementById('jumlah');
    let harga = document.getElementById('harga');
    let hargaOriginal;
    let viewsubtotal = document.getElementById('subtotal');
    let viewtotal = document.getElementById('total');
    
    // aksi
    jumlah.addEventListener('input', () => {
      if (jumlah.value < 0) {
        viewsubtotal.innerHTML = "Rp. 0"
        viewtax.innerHTML = "Rp. 0";
      } else {
        // Hitung Subtotal
        const hargaConvert = (harga.value).replace(/[Rp,.]/g,'')
        hargaOriginal = hargaConvert;
        let subtotal = hargaConvert * jumlah.value;
        //  Hitung Total
        let total =  subtotal;

       viewsubtotal.innerHTML = "Rp. " + subtotal;
       viewtotal.innerHTML = "Rp. " + total;
      } 
     
    });
    function hitungtotal(){
    let price = parseInt(document.getElementById("harga").value);
    let jumlah = parseInt(document.getElementById("jumlah").value);
    let diskon = parseInt(document.getElementById("diskon").value);
    
    let totalHarga = price * jumlah;
    let potonganDiskon = (totalHarga * diskon) / 100;
    let totalhargaSetelahDiskon = totalHarga - potonganDiskon;
    
    document.getElementById("total-setelah-diskon").value = totalhargaSetelahDiskon;

 
    
    document.getElementById("total-harga").value = totalHarga;
     }

    function hitungkembalian(){
        const pembayaran = document.getElementById('pembayaran-id');
        const kembalian = document.getElementById('kembalian-id');

        const countkembalian = parseInt(pembayaran.value) - parseInt(hargaOriginal);
        console.log({pembayaran : pembayaran.value, hargaOriginal: hargaOriginal })
        if(countkembalian < 0 ){
            kembalian.value = 0
        } else {
            kembalian.value = countkembalian.toLocaleString('id-ID',{
            style: 'currency',
            currency : 'IDR'
        })
        }

        
    }

    function simpan(){
      alert("Bookingan Anda Sedang Di Terima")
      window.location = 'home.php'
    }
  </script>
</body>
</html>