<?php
$data = [
    [
        "id" => 0,
        "nama" => "jaheXpress",
        "deskripsi" => "isi deskripsi produk JaheXpress",
        "harga" => 3000,
        "gambar" => "jahe.jpg",
    ],
    [
        "id" => 1,
        "nama" => "BungaTelang",
        "deskripsi" => "isi deksripsi produk Bunga Telang",
        "harga" => 5000,
        "gambar" => "bunga.jpg",
    ],
    [
        "id" => 2,
        "nama" => "LulurKopi",
        "deskripsi" => "isi deksripsi produk Lulur Kopi",
        "harga" => 4500,
        "gambar" => "lulur.jpg",
    ],
    [
        "id" => 3,
        "nama" => "LulurIntanSari",
        "deskripsi" => "isi deskripsi produk Lulur Intan Sari",
        "harga" => 3500,
        "gambar" => "lulur2.jpg",
    ],
];