<?php
        //jika button login di tekan maka akan menjalankan codingan yang didalam ini
    if(isset($_POST["login"])){
    // jika nilai pada inputan username sama dengan "userlsp" 
    // dan jika nilai pada inputan password sama dengan "juan"
        if($_POST["username"]=="userlsp" && $_POST["password"]=="juan"){
            // memulai session
            session_start();
            // menyimpan nilai username pada session
            $_SESSION['username']= $_POST['username'];
            // untuk memindahkan user ke halaman index.php
            header("location: index.php");
        }
        else{
            echo"
            <script>
            alert('username atau password yang anda masukkan salah')
            </script>
            ";
        }
    }
    ?>