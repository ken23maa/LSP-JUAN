<?php
$datahp = [
    [
        'id' => 0,
        'name' => 'iphone11',
        'description' => 'Warna Hijau - Memory 128GB',
        'price' => 7125000,
        'gambar' => 'iphone11.jpg'
    ],
    [
        'id' => 1,
        'name' => 'iphone13',
        'description' => 'Warna Pink - Memory 128GB',
        'price' => 10125000,
        'gambar' => 'iphone13.jpg'
    ],
    [
        'id' => 2,
        'name' => 'iphone12 Pro',
        'description' => 'Warna Black - Memory 256GB',
        'price' => 14500000,
        'gambar' => 'iphone12.jpg',
    ],
    [
        'id' => 3,
        'name' => 'iphone14',
        'description' => 'Warna Gret - Memory 512GB',
        'price' => 15125000,
        'gambar' => 'iphone14.jpg',
    ],
]
?>