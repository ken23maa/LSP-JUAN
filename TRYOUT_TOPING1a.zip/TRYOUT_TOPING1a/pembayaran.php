<?php
require 'data.php';
$id = $_GET['id'];

session_start();
if(!isset($_SESSION['username'])){
    header('Location : login.php');
}

$username = $_SESSION['username'];
?>

<!doctype html>
<html lang="en">

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Applebox</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    </head>
    <body>

            <nav class="navbar navbar-expand-lg bg-body border-bottom sticky-top">
            <div class="container">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                <div class="navbar-nav ms-auto">
                <a class="nav-link active" href="#">Home</a>
                <a class="nav-link" href="#">Pembayaran</a>
                <a class="nav-link" href="login.php">Logout</a>
                </div>
            </div>
            </div>
        </nav>

        <div class="container">
            <h1>Pembayaran Applebox</h1>

            <form action="">
                <div class="mb-3">
                    <label for="title" class="form-label">No Transaksi :</label>
                    <input type="text" id="transaksi" class="form-control" value="">
                </div>

                <div class="mb-3">
                    <label for="no-transaksi" class="form-label">Tanggal Transaksi :</label>
                    <input type="date" id="tanggal" class="form-control" value="" >
                </div>

                <div class="mb-3">
                    <label for="nama-pembeli" class="form-label">Nama Pembeli :</label>
                    <input type="text" id="nama" class="form-control" value="">
                </div>

                <div class="mb-3">
                    <label for="jus" class="form-label">Pilihan Handphone :</label>
                    <input type="text" id="jus" class="form-control" value="<?= $datahp[$id]['name'] ?>" readonly>
                </div>

                <div class="mb-3">
                    <label for="price" class="form-label">Harga :</label>
                    <input type="text" id="price" class="form-control" value="<?= $datahp[$id]['price'] ?>" readonly>
                </div>


                <!--Toping -->
                <div class="mb-3">
                    <input type="radio" id="cassing" name="toping" value="50000">
                    <label for="text">Cassing : 50000</label> <br>
                    <input type="radio" id="headset" name="toping" value="20000">
                    <label for="text">Headset : 20000</label> <br>
                    <input type="radio" id="carger" name="toping" value="100000">
                    <label for="text">Carger : 100000</label> <br>
                </div>

                <div class="mb-3">
                    <label for="jumlah" class="form-label">Jumlah Dibeli : </label>
                    <input type="number" id="jumlah" class="form-control">
                </div>

                <button type="button" onclick="hitungtotal()" class="btn btn-primary">Hitung Total</button>

                <div class="mb-3">
                    <label for="total" class="form-label">Total Bayar : </label>
                    <input type="number" id="totalHarga" name="totalHarga" class="form-control">
                </div>

                <div class="mb-3">
                    <label for="pembayaran" class="form-label">Pembayaran : </label>
                    <input type="number" id="pembayaran" class="form-control">
                </div>

                <button type="button" onclick="hitungKembalian()" class="btn btn-primary">Hitung Kembalian</button>

                <div class="mb-3">
                    <label for="total" class="form-label">Kembalian : </label>
                    <input type="number" id="kembalian" class="form-control">
                </div>
                <button type="button" onclick="window.location.href='index.php'" class="btn btn-primary">Simpan Transaksi</button>

            </form>

        
        </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

    <script>
        function hitungtotal() {
            // variabel price menyimpan element HTML yang ber id "price" dan di ambil nilainya lalu di ubah menjadi integer
            let price = parseInt(document.getElementById("price").value);
            let jumlah = parseInt(document.getElementById("jumlah").value);
            // variabel toping menyimpan element HTML  input[name="toping] yang ada tanda checked nya
            let toping = document.querySelector('input[name="toping"]:checked');
            // variabel topingHarga menyimpan jika ada toping nya maka akan mengambil nilainya
            // dan di ubah ke integer jika tidak ada pilihan toping maka nilainya 0
            let topingHarga = toping ? parseInt(toping.value) : 0;
            let  totalHarga = (price + topingHarga) * jumlah;
            // element HTML yang ber id "total harga" valuenya menampilkan totalHarga
            document.getElementById("totalHarga").value = totalHarga;
            
        }
        
        function hitungKembalian(){
            let price = parseInt(document.getElementById("totalHarga").value);
            let pembayaran = parseInt(document.getElementById("pembayaran").value);

                let kembalian = pembayaran - price;
                document.getElementById("kembalian").value = kembalian;
            
    }
    
    const proses = document.getElementById('proses');
// ketika element yang ber id proses click akan berpindah ke halaman index.php
proses.addEventListener('click', function() {
    window.location = "index.php";
});
    </script>

    </body>
</html>